<footer class="text-center">
    &nbsp;
    &copy; 2020 <a href="https://github.com/rocknrold/spa-movie">MOVIE-WEB-APP</a>
    <br>
    <a href="https://github.com/rocknrold">Aaron, Harold C.</a>
</footer>
