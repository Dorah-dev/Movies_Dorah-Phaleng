@extends('layouts.app')
@section('scripts')
<script src="{{asset('js/logout.js')}}"></script>
@endsection