@component('mail::message')
<h1>You are now an authenticated user in <strong>movie web app!!!</strong></h1>
<span>Thank you for logging in!</span>
<P>Feel free to use the resource!!!</p>