<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FilmProducer extends Model
{
    //
}
