<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ActorRole extends Model
{
    protected $table = 'actor_film';
}
